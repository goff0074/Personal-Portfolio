# Example input and outputs for HW3

# Your program should be run like this (if using python):
python <programname> example.fna

# Your program should output these files:
genetic-distances.txt
edges.txt
bootstrap.txt

# Plots were generated with provided script:
Rscript ../hw3-plot-edges.r edges.txt example-tip-labels.txt tree.pdf
Rscript ../hw3-plot-edges.r edges.txt example-tip-labels.txt bootstrap.txt tree-bootstrap.pdf
